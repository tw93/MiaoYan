import { render } from "./mermaid-layout-elk-render.js";
export default { render };
