# Ideas & Brainstorming

Capture your creative thoughts and ideas here.

**Try This:**

- Type `/markmap` + `Tab` for mind mapping
- Type `/mermaid` + `Tab` for diagrams
- Type `/task` + `Tab` for task lists
